import { supabase } from "@/services/supabase/client";

export async function getRouteCoverageView(
  routeId: string
) {
  const { data, error } =
    await supabase
      .from("route_coverage")
      .select(`
        neighborhood_id,

        neighborhoods (
          id,
          name,

          districts (
            id,
            name,

            cantons (
              id,
              name,

              provinces (
                id,
                name
              )
            )
          )
        )
      `)
      .eq(
        "route_id",
        routeId
      );

  if (error) {
    throw error;
  }

  return (
    data?.map(
      (
        item: any
      ) => ({
        id:
          item.neighborhoods.id,

        province:
          item
            .neighborhoods
            .districts
            .cantons
            .provinces
            .name,

        canton:
          item
            .neighborhoods
            .districts
            .cantons
            .name,

        district:
          item
            .neighborhoods
            .districts
            .name,

        neighborhood:
          item
            .neighborhoods
            .name,
      })
    ) || []
  );
}